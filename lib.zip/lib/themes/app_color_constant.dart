import 'package:flutter/material.dart';

class AppColorConstant {
  AppColorConstant._();

  static const Color primaryColor = Colors.red;
  static const Color appBarColor = Colors.yellow;
}
